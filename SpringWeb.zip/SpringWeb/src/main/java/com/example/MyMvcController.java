package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyMvcController {
	@RequestMapping("/add")
	public ModelAndView sayHello()
	{
		ModelAndView mv=new ModelAndView();
		
		mv.setViewName("Sample");
		return mv;
	}

}
